@echo off
setlocal enabledelayedexpansion

:START
:: Fetch all available COM ports (connected or not)
set "COMPORTS="
for /f "tokens=*" %%i in ('powershell -command "[System.IO.Ports.SerialPort]::getportnames()"') do (
    set "port=%%i"
    set "isDuplicate=0"
    
    :: Check for duplicates
    for %%j in (!COMPORTS!) do (
        if "!port!"=="%%j" (
            set "isDuplicate=1"
            goto :continue
        )
    )

    :continue
    if "!isDuplicate!"=="0" (
        set "COMPORTS=!COMPORTS! !port!"
    )
)

:: Check if COMPORTS is empty
if "%COMPORTS%"=="" (
    echo No COM ports found.
    pause
    exit /b
)

:: Display available COM ports with numbered options
echo Available COM Ports:
set /a count=1
for %%i in (%COMPORTS%) do (
    echo   !count!. %%i
    set "COM_!count!=%%i"
    set /a count+=1
)

:: Prompt user for selection
set /p choice="Select COM port list number [Not COM NUMBER]: "

:: Validate selection and set the chosen COM port
set "selectedCOM=!COM_%choice%!"
if "%selectedCOM%"=="" (
    echo Invalid selection. Exiting...
    exit /b
)

:: Show selected COM port
echo Selected COM Port: %selectedCOM%

:: Flashing process

esptool.exe --chip esp32s3 --port %selectedCOM% --baud 921600 --before default-reset --after hard-reset write-flash -e -z --flash-mode keep --flash-freq keep --flash-size keep 0x0 code_files/uncanny_eye_pendant_v2.ino.bootloader.bin 0x8000 code_files/uncanny_eye_pendant_v2.ino.partitions.bin 0xe000 code_files/boot_app0.bin 0x10000 code_files/uncanny_eye_pendant_v2.ino.bin 

echo Flashing complete on %selectedCOM%.

:: Prompt to flash again
echo.
echo Press any key to flash again, or close the window to exit.
pause >nul
goto START